package br.edu.unibratec.imc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    private TextView textViewResultTitle;
    private ImageView imageViewResultDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Intent intent = getIntent();
        double result = intent.getDoubleExtra("result", 0.0);

        textViewResultTitle = findViewById(R.id.textview_result_title);
        imageViewResultDisplay = findViewById(R.id.imageview_result_display);

        if(result < 18.5) {
            textViewResultTitle.setText("Abaixo: IMC " + String.format("%.2f", result));
            imageViewResultDisplay.setImageResource(R.drawable.ic_bellow);
        }else if(result >= 25) {
            textViewResultTitle.setText("Acima: IMC " + String.format("%.2f", result));
            imageViewResultDisplay.setImageResource(R.drawable.ic_above);
        }else {
            textViewResultTitle.setText("Normal: IMC " + String.format("%.2f", result));
        }
    }
}
