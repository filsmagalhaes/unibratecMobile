package br.edu.unibratec.imc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextMainWeight;
    private EditText editTextMainHeight;
    private Button buttonMainCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextMainWeight = findViewById(R.id.edittext_main_weight);
        editTextMainHeight = findViewById(R.id.edittext_main_height);
        buttonMainCalculate = findViewById(R.id.button_main_calculate);

        buttonMainCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editTextMainWeight.getText().toString().trim().equals("")) {
                    Toast.makeText(MainActivity.this, "Informe o peso", Toast.LENGTH_SHORT).show();
                }else if(editTextMainHeight.getText().toString().trim().equals("")){
                    Toast.makeText(MainActivity.this, "Informe a altura", Toast.LENGTH_SHORT).show();
                }else {
                    double weight = Double.parseDouble(editTextMainWeight.getText().toString());
                    double height = Double.parseDouble(editTextMainHeight.getText().toString());
                    double imc = weight / Math.pow(height, 2);
                    Intent intent = new Intent(v.getContext(), ResultActivity.class);
                    intent.putExtra("result", imc);
                    startActivity(intent);
                }
            }
        });
    }
}
